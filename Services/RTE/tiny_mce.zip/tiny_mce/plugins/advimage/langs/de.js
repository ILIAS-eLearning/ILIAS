// DE lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Allgemein',
tab_appearance : 'Erscheinungsbild',
tab_advanced : 'Erweitert',
general : 'Allgemein',
title : 'Titel',
preview : 'Vorschau',
constrain_proportions : 'Verh&auml;ltnis beibehalten',
langdir : 'Sprachrichtung',
langcode : 'Sprach-Code',
long_desc : 'Link zu ausf&uuml;hrlicher Beschreibung',
style : 'CSS-Stil',
classes : 'CSS-Klassen',
ltr : 'Von links nach rechts',
rtl : 'Von rechts nach links',
id : 'ID',
image_map : 'Image Map (Bild mit sensitiven Bereichen)',
swap_image : 'Bild austauschen',
alt_image : 'Alternatives Bild',
mouseover : 'f&uuml;r Mouse-Over',
mouseout : 'f&uuml;r Mouse-Out',
misc : 'Sonstiges',
example_img : 'Erscheinungsbild&nbsp;Vorschau&nbsp;Bild',
missing_alt : 'Are you sure you want to continue without including an Image Description? Without  it the image may not be accessible to some users with disabilities, or to those using a text browser, or browsing the Web with images turned off.'
});
