// DE lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */
/* Sprachparameter m�ssen als lang_<Eigenes Plugin>_<Eigener Name> definiert werden */

tinyMCE.addToLang('',{
latex_title : 'LaTeX',
latex_desc : 'Dieses Kommando kennzeichnet den markierten Text als LaTeX-Code'
});
