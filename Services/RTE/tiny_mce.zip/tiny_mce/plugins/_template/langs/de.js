// DE lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */
/* Sprachparameter m�ssen als lang_<Eigenes Plugin>_<Eigener Name> definiert werden */

tinyMCE.addToLang('',{
template_title : 'Dies ist nur ein Beispiel-Popup',
template_desc : 'Dies ist nur ein Beispiel-Button'
});
