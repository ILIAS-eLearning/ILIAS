// DE lang variables 

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Suchen',
searchreplace_searchnext_desc : 'Erneut suchen',
searchreplace_replace_desc : 'Suchen/Ersetzen',
searchreplace_notfound : 'Die Suche wurde abgeschlossen. Das Suchwort wurde nicht gefunden.',
searchreplace_search_title : 'Suchen',
searchreplace_replace_title : 'Suchen/Ersetzen',
searchreplace_allreplaced : 'Die Suche wurde abgeschlossen. Alle Vorkommen wurden ersetzt.',
searchreplace_findwhat : 'Suchen nach',
searchreplace_replacewith : 'Ersetzen durch',
searchreplace_direction : 'Suchrichtung',
searchreplace_up : 'R&uuml;ckw&auml;rts',
searchreplace_down : 'Vorw&auml;rts',
searchreplace_case : 'Gro&szlig;-/Kleinschreibung beachten',
searchreplace_findnext : 'Weitersuchen',
searchreplace_replace : 'Ersetzen',
searchreplace_replaceall : 'Alle ersetzen',
searchreplace_cancel : 'Abbrechen',
searchreplace_replace_delta_width : 50
});
