XHTML Xtras Plugin for TinyMCE 2.0.3 and up
Andrew tetlaw 2006/02/21
http://tetlaw.id.au/view/blog/xhtml-xtras-plugin-for-tinymce/

This is a plugin to enable the insert/update of some lesser used XHTML elements. Add 'xhtmlxtras' to your plugins, and then you have the following buttons available for your toolbars:

'cite' : Citation element
'abbr' : Abbreviation element
'acronym' : Acronym element
'del' : Deletion element
'ins' : Insertion element

The popup dialog boxes contain fields for the attributes allowed under the specification (standard events not included yet). For example, select some text and click the acronym button. Type in the definition into the 'Title' field for the tooltip. The remove button will remove the element only, not the text.

The plugin includes a CSS file which will be imported for viewing the above elements in your editor content. The included buttons suck, for the love of God, please help!