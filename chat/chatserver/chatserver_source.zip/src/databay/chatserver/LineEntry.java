/*
 * $Id: LineEntry.java,v 1.4 2005/06/30 08:12:45 krichter Exp $
 */
package databay.chatserver;

import org.apache.log4j.Logger;

/**
 * Klasse fuer die Aufnahme einer Nachrichtenzeile 
 */
public class LineEntry
{
    private Logger logger = Logger.getLogger(this.getClass());
    private String message;
    private String fromNick;
    private String toNick;
    private long timestamp;

    public LineEntry(String message,String fromNick,String toNick)
    {
        this.timestamp = System.currentTimeMillis()/1000;
    	this.toNick = new String(toNick);
    	this.fromNick =  new String(fromNick);
    	this.message =  new String(message);
        logger.debug("LineEntry-MESSAGE: "+message);
    }
    /** 
     * gibt die Nachricht aus
     **/
    public String getMessage()
    {
    	return message;
    }

    /**
     * gibt den Absender der Nachricht aus
     */
    public String getFromNick()
    {
    	return fromNick;
    }

    /**
     * gibt aus an wen die Nachricht gerichtet ist (kann null sein)
     */
    public String getToNick()
    {
    	return toNick;
    }

    public long getTimestamp()
    {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp)
    {
        this.timestamp = timestamp;
    }
}
